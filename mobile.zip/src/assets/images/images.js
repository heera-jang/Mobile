const IMAGES = {
    bg1: new URL('./bg1.jpg', import.meta.url).href,
    bg2: new URL('./bg2.jpg', import.meta.url).href,
    bg3: new URL('./bg3.jpg', import.meta.url).href,
    bg4: new URL('./bg4.jpg', import.meta.url).href,
    bg6: new URL('./bg5.jpg', import.meta.url).href
 }
 export default IMAGES;